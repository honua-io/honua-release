"""Protocol-dispatch helpers shared by the sync and async client query facades.

The :meth:`HonuaClient.query` / :meth:`AsyncHonuaClient.query` (and their
``iter_query`` / ``_collect_query_pages`` siblings) all dispatch the same
shape: validate the query, normalize the protocol, build a protocol-specific
kwargs dict, walk the protocol-wrapper iterator, then convert each item to a
:class:`QueryFeature`. The wrappers themselves are inherently sync-or-async
(httpx ``for`` vs ``async for``), so the loops live in the client modules,
but everything around them is pure and lives here.

Public helpers (callable from both ``client.py`` and ``async_client.py``):

- :func:`validate_filter_routing` -- reject silent ``where``→CQL forwarding
- :func:`merge_idempotency_into_headers` -- fold ``Idempotency-Key`` into
  ``extra_headers`` so the dispatcher can fan out a single mapping
- :func:`merge_request_headers` -- per-request header precedence merge
- :func:`feature_server_pages_kwargs` / :func:`feature_server_items_kwargs`
- :func:`ogc_features_pages_kwargs` / :func:`ogc_features_items_kwargs`
- :func:`stac_pages_kwargs` / :func:`stac_items_kwargs`
- :func:`odata_pages_kwargs` / :func:`odata_items_kwargs`
- :func:`reject_odata_bbox` -- raise ``ValueError`` when ``bbox`` is set on
  an OData query (sync and async dispatcher share the same wording)
"""

from __future__ import annotations

import warnings
from collections.abc import Mapping
from typing import Any

import httpx

from ._http import merge_request_headers
from ._query import (
    bbox_text,
    feature_server_extra_params,
    features_from_geojson_page,
    field_list,
    field_text,
    odata_features_from_page,
    odata_layer_id,
    odata_pagination_signals,
    ogc_pagination_signals,
    query_feature_from_feature_server,
    query_feature_from_geojson,
    query_feature_from_mapping,
    query_filter,
    query_page_size,
)
from .models import FeatureQuery, QueryFeature

# Protocols whose ``filter`` slot expects CQL2-text; rejecting silent
# ``where``→CQL forwarding here keeps the legacy dispatcher honest.
_CQL_FILTER_DISPATCH_PROTOCOLS = frozenset(("ogc-features", "stac"))


def validate_filter_routing(query: FeatureQuery, normalized_protocol: str) -> None:
    """Reject silent ``where``→CQL forwarding on OGC Features / STAC.

    Mirrors the rule enforced by :func:`honua_sdk.source._feature_query_for_source`
    so the legacy :meth:`HonuaClient.query` / :meth:`HonuaClient.iter_query`
    dispatcher does not quietly route a SQL-style ``where`` clause into a
    CQL2-text ``filter`` slot. The dispatcher operates on
    :class:`FeatureQuery`, whose ``filter`` slot is the CQL2-text channel
    (the equivalent of ``Query.cql_filter`` on the canonical facade); we
    require callers to use that slot (or ``Source.query`` with
    ``where_as_cql=True``) instead.
    """
    if normalized_protocol not in _CQL_FILTER_DISPATCH_PROTOCOLS:
        return
    if query.where is not None and query.filter is None:
        raise ValueError(
            "Query.where is a SQL-style filter; pass `cql_filter=...` "
            "(CQL2-text) when targeting OGC Features or STAC. To accept "
            "silent forwarding, pass where_as_cql=True explicitly."
        )


def warn_if_truncated(query: FeatureQuery, *, exceeded: bool, pages_seen: int) -> None:
    """Warn when a bounded page walk stopped with more features still available.

    A million-feature iterate that silently halts at the page cap is a footgun.
    When ``query.max_pages`` is a finite cap, the walk reached it
    (``pages_seen >= max_pages``), and the server still advertises more
    (``exceeded`` is its ``exceededTransferLimit`` / next-link signal), we emit
    a :class:`ResourceWarning` so the truncation is visible. Pass
    ``max_pages=None`` for an unbounded walk to suppress the cap entirely; a
    ``limit`` (the caller's own ceiling) also suppresses it.
    """
    if query.limit is not None:
        return
    max_pages = query.max_pages
    if not exceeded or max_pages is None or pages_seen < max_pages:
        return
    warnings.warn(
        f"Query stopped after the max_pages={max_pages} cap with more features "
        "still available on the server (exceededTransferLimit). Increase "
        "max_pages, set max_pages=None for an unbounded walk, or pass a limit "
        "to acknowledge the truncation.",
        ResourceWarning,
        stacklevel=3,
    )


def merge_idempotency_into_headers(
    extra_headers: Mapping[str, str] | None,
    idempotency_key: str | None,
) -> Mapping[str, str] | None:
    """Fold ``idempotency_key`` into ``extra_headers`` for dispatcher fan-out.

    The query / iter_query dispatcher forwards a single ``extra_headers``
    mapping into each protocol's pagination wrapper, so we merge any
    explicit ``idempotency_key`` here. Returns the original mapping
    unchanged (or ``None``) when no key is supplied so we don't
    needlessly copy.
    """
    if idempotency_key is None:
        return extra_headers
    merged: dict[str, str] = dict(extra_headers) if extra_headers else {}
    merged["Idempotency-Key"] = idempotency_key
    return merged


# ---------------------------------------------------------------------------
# Protocol-specific kwarg builders for the wrapper iterators
# ---------------------------------------------------------------------------


def _feature_server_layer_id(query: FeatureQuery) -> int:
    """FeatureServer layers default to ``0`` when unspecified on the query."""
    return 0 if query.layer_id is None else query.layer_id


def _feature_server_where_text(query: FeatureQuery) -> str:
    """FeatureServer accepts ``where`` (preferred) or ``filter``; default ``1=1``."""
    return query.where if query.where is not None else (query.filter or "1=1")


def feature_server_pages_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``feature_server(...).query_pages(...)`` (dispatcher fan-out).

    Shared by sync and async ``_collect_query_pages``. The positional
    ``layer_id`` is included as ``layer_id=...`` so callers can ``**spread``
    it without an extra positional.
    """
    return {
        "layer_id": _feature_server_layer_id(query),
        "where": _feature_server_where_text(query),
        "out_fields": field_text(query.fields, wildcard="*") or "*",
        "return_geometry": query.return_geometry,
        "page_size": query_page_size(query, 1000),
        "limit": query.limit,
        # ``query.max_pages`` is passed through verbatim: ``None`` means
        # *unbounded* (walk every page the server advertises) rather than the
        # old silent 100-page cap. The canonical ``query``/``iter_query`` and
        # ``Source`` methods default the cap to 100 at their own signatures, so
        # ``None`` here only ever arrives when a caller explicitly opted in.
        "max_pages": query.max_pages,
        "extra_params": feature_server_extra_params(query),
        "timeout": timeout,
        "extra_headers": extra_headers,
    }


def feature_server_items_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``feature_server(...).query_items(...)`` (iter_query fan-out)."""
    return feature_server_pages_kwargs(
        query, timeout=timeout, extra_headers=extra_headers
    )


def ogc_features_pages_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``ogc_features().collection(...).items_pages(...)``."""
    return {
        "filter": query_filter(query),
        "bbox": query.bbox,
        "properties": field_list(query.fields),
        "page_size": query.page_size,
        "limit": query.limit,
        "max_pages": query.max_pages,
        "extra_params": query.extra_params,
        "timeout": timeout,
        "extra_headers": extra_headers,
    }


def ogc_features_items_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``ogc_features().collection(...).iter_items(...)``."""
    return ogc_features_pages_kwargs(
        query, timeout=timeout, extra_headers=extra_headers
    )


def _stac_extra_params(query: FeatureQuery) -> dict[str, Any]:
    """Assemble the STAC ``extra_params`` dict from the canonical query slots.

    STAC's search endpoint encodes ``bbox`` / ``filter`` / ``fields`` as
    query-string params rather than dedicated kwargs on the iterator, so
    we splice them into ``extra_params`` (preserving any caller-supplied
    values via ``setdefault``).
    """
    params = dict(query.extra_params)
    if query.bbox is not None:
        params.setdefault("bbox", bbox_text(query.bbox))
    if query_filter(query) is not None:
        params.setdefault("filter", query_filter(query))
    if field_text(query.fields) is not None:
        params.setdefault("fields", field_text(query.fields))
    return params


def stac_pages_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``stac().item_pages(query.source, ...)``."""
    return {
        "extra_params": _stac_extra_params(query),
        "page_size": query.page_size,
        "limit": query.limit,
        "max_pages": query.max_pages,
        "timeout": timeout,
        "extra_headers": extra_headers,
    }


def stac_items_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``stac().iter_items(query.source, ...)``."""
    return stac_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers)


def reject_odata_bbox(query: FeatureQuery) -> None:
    """OData has no spatial-filter equivalent; reject ``bbox`` at the dispatcher."""
    if query.bbox is not None:
        raise ValueError(
            "bbox is not supported for OData shared queries; "
            "express spatial filters in `filter`."
        )


def odata_pages_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``odata().features_pages(...)`` (dispatcher fan-out).

    Callers must invoke :func:`reject_odata_bbox` first; this helper does
    not re-validate ``bbox``.
    """
    return {
        "layer_id": odata_layer_id(query),
        "filter": query_filter(query),
        "select": field_list(query.fields),
        "page_size": query.page_size,
        "limit": query.limit,
        "max_pages": query.max_pages,
        "extra_params": query.extra_params,
        "timeout": timeout,
        "extra_headers": extra_headers,
    }


def odata_items_kwargs(
    query: FeatureQuery,
    *,
    timeout: float | httpx.Timeout | None,
    extra_headers: Mapping[str, str] | None,
) -> dict[str, Any]:
    """Kwargs for ``odata().iter_features(...)`` (iter_query fan-out)."""
    return odata_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers)


def _extend_collected_query_features(
    collected: list[QueryFeature],
    items: list[QueryFeature],
    limit: int | None,
) -> bool:
    if limit is not None:
        remaining = limit - len(collected)
        if remaining <= 0:
            return True
        items = items[:remaining]
    collected.extend(items)
    return limit is not None and len(collected) >= limit


def collect_query_pages(
    client: Any,
    query: FeatureQuery,
    normalized_protocol: str,
    *,
    timeout: float | httpx.Timeout | None = None,
    extra_headers: Mapping[str, str] | None = None,
) -> tuple[tuple[QueryFeature, ...], bool, int | None, int]:
    """Walk protocol pages and collect normalized query features (sync)."""
    collected: list[QueryFeature] = []
    exceeded = False
    total_count: int | None = None
    pages_seen = 0
    limit = query.limit

    if normalized_protocol == "feature-server":
        for page in client.feature_server(query.source).query_pages(
            **feature_server_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
        ):
            pages_seen += 1
            exceeded = bool(page.exceeded_transfer_limit)
            page_features = [
                query_feature_from_feature_server(
                    feature, source=query.source, protocol=normalized_protocol
                )
                for feature in page.features
            ]
            if _extend_collected_query_features(collected, page_features, limit):
                break
        return tuple(collected), exceeded, None, pages_seen

    if normalized_protocol == "ogc-features":
        last_page: Any = None
        for page in client.ogc_features().collection(query.source).items_pages(
            **ogc_features_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
        ):
            pages_seen += 1
            last_page = page
            page_features = [
                query_feature_from_geojson(
                    item, source=query.source, protocol=normalized_protocol
                )
                for item in features_from_geojson_page(page)
            ]
            if _extend_collected_query_features(collected, page_features, limit):
                break
        total_count, exceeded = ogc_pagination_signals(last_page)
        return tuple(collected), exceeded, total_count, pages_seen

    if normalized_protocol == "stac":
        last_page = None
        for page in client.stac().item_pages(
            query.source,
            **stac_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
        ):
            pages_seen += 1
            last_page = page
            page_features = [
                query_feature_from_geojson(
                    item, source=query.source, protocol=normalized_protocol
                )
                for item in features_from_geojson_page(page)
            ]
            if _extend_collected_query_features(collected, page_features, limit):
                break
        total_count, exceeded = ogc_pagination_signals(last_page)
        return tuple(collected), exceeded, total_count, pages_seen

    reject_odata_bbox(query)
    last_page = None
    for page in client.odata().features_pages(
        **odata_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
    ):
        pages_seen += 1
        last_page = page
        page_features = [
            query_feature_from_mapping(
                item, source=query.source, protocol=normalized_protocol
            )
            for item in odata_features_from_page(page)
        ]
        if _extend_collected_query_features(collected, page_features, limit):
            break
    total_count, exceeded = odata_pagination_signals(last_page)
    return tuple(collected), exceeded, total_count, pages_seen


async def collect_query_pages_async(
    client: Any,
    query: FeatureQuery,
    normalized_protocol: str,
    *,
    timeout: float | httpx.Timeout | None = None,
    extra_headers: Mapping[str, str] | None = None,
) -> tuple[tuple[QueryFeature, ...], bool, int | None, int]:
    """Walk protocol pages and collect normalized query features (async)."""
    collected: list[QueryFeature] = []
    exceeded = False
    total_count: int | None = None
    pages_seen = 0
    limit = query.limit

    if normalized_protocol == "feature-server":
        async for page in client.feature_server(query.source).query_pages(
            **feature_server_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
        ):
            pages_seen += 1
            exceeded = bool(page.exceeded_transfer_limit)
            page_features = [
                query_feature_from_feature_server(
                    feature, source=query.source, protocol=normalized_protocol
                )
                for feature in page.features
            ]
            if _extend_collected_query_features(collected, page_features, limit):
                break
        return tuple(collected), exceeded, None, pages_seen

    if normalized_protocol == "ogc-features":
        last_page: Any = None
        async for page in client.ogc_features().collection(query.source).items_pages(
            **ogc_features_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
        ):
            pages_seen += 1
            last_page = page
            page_features = [
                query_feature_from_geojson(
                    item, source=query.source, protocol=normalized_protocol
                )
                for item in features_from_geojson_page(page)
            ]
            if _extend_collected_query_features(collected, page_features, limit):
                break
        total_count, exceeded = ogc_pagination_signals(last_page)
        return tuple(collected), exceeded, total_count, pages_seen

    if normalized_protocol == "stac":
        last_page = None
        async for page in client.stac().item_pages(
            query.source,
            **stac_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
        ):
            pages_seen += 1
            last_page = page
            page_features = [
                query_feature_from_geojson(
                    item, source=query.source, protocol=normalized_protocol
                )
                for item in features_from_geojson_page(page)
            ]
            if _extend_collected_query_features(collected, page_features, limit):
                break
        total_count, exceeded = ogc_pagination_signals(last_page)
        return tuple(collected), exceeded, total_count, pages_seen

    reject_odata_bbox(query)
    last_page = None
    async for page in client.odata().features_pages(
        **odata_pages_kwargs(query, timeout=timeout, extra_headers=extra_headers),
    ):
        pages_seen += 1
        last_page = page
        page_features = [
            query_feature_from_mapping(
                item, source=query.source, protocol=normalized_protocol
            )
            for item in odata_features_from_page(page)
        ]
        if _extend_collected_query_features(collected, page_features, limit):
            break
    total_count, exceeded = odata_pagination_signals(last_page)
    return tuple(collected), exceeded, total_count, pages_seen


__all__ = [
    "collect_query_pages",
    "collect_query_pages_async",
    "feature_server_items_kwargs",
    "feature_server_pages_kwargs",
    "merge_idempotency_into_headers",
    "merge_request_headers",
    "odata_items_kwargs",
    "odata_pages_kwargs",
    "ogc_features_items_kwargs",
    "ogc_features_pages_kwargs",
    "reject_odata_bbox",
    "stac_items_kwargs",
    "stac_pages_kwargs",
    "validate_filter_routing",
    "warn_if_truncated",
]
