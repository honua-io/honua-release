"""GeoPandas integration for converting geospatial responses to GeoDataFrames.

This module requires the optional ``geopandas`` extra::

    pip install honua-sdk[geopandas]
"""

from __future__ import annotations

import math
import re
from collections.abc import Mapping
from datetime import date, datetime
from typing import Any

try:
    import geopandas as gpd
    import pandas as pd
    from shapely.geometry import (
        LinearRing,
        MultiLineString,
        MultiPoint,
        Point,
        Polygon,
    )
    from shapely.geometry import (
        shape as _shape,
    )

    _HAS_DEPS = True
except ImportError:
    _HAS_DEPS = False


def _ensure_deps() -> None:
    if not _HAS_DEPS:
        raise ImportError(
            "geopandas and shapely are required for GeoPandas integration. "
            "Install them with:  pip install honua-sdk[geopandas]"
        )


# ---------------------------------------------------------------------------
# Well-known Esri WKID -> EPSG mappings for spatial references that do not
# map 1:1 to an EPSG code.
# ---------------------------------------------------------------------------
_WKID_TO_EPSG: dict[int, str] = {
    102100: "EPSG:3857",
    102113: "EPSG:3857",
    3857: "EPSG:3857",
    4326: "EPSG:4326",
}
_GEOJSON_DEFAULT_CRS = "EPSG:4326"
#: EPSG code for WGS84 longitude/latitude (the GeoJSON default CRS).
_WGS84_EPSG = 4326
#: EPSG code for Web Mercator, and the legacy Esri ``wkid`` for the same CRS.
_WEB_MERCATOR_EPSG = 3857
_WEB_MERCATOR_ESRI_WKID = 102100


def _crs_from_spatial_reference(
    spatial_ref: dict[str, Any] | None,
) -> str | None:
    """Derive a CRS string from an Esri ``spatialReference`` dict.

    Returns ``None`` when the spatial reference is absent or cannot be mapped.
    """
    if not spatial_ref:
        return None

    for key in ("latestWkid", "wkid"):
        wkid = spatial_ref.get(key)
        if wkid is not None:
            if wkid in _WKID_TO_EPSG:
                return _WKID_TO_EPSG[wkid]
            return f"EPSG:{wkid}"

    return None


def _crs_from_geojson(feature_collection: Mapping[str, Any]) -> str | None:
    """Derive a CRS string from a GeoJSON feature collection."""
    raw_crs = feature_collection.get("crs") or feature_collection.get("coordRefSys")
    if raw_crs is None:
        return _GEOJSON_DEFAULT_CRS

    if isinstance(raw_crs, str):
        return _normalize_geojson_crs_identifier(raw_crs)

    if isinstance(raw_crs, Mapping):
        properties = raw_crs.get("properties")
        if isinstance(properties, Mapping):
            for key in ("name", "href", "code"):
                value = properties.get(key)
                if isinstance(value, str):
                    return _normalize_geojson_crs_identifier(value)

        for key in ("name", "href", "code"):
            value = raw_crs.get(key)
            if isinstance(value, str):
                return _normalize_geojson_crs_identifier(value)

    return None


def _normalize_geojson_crs_identifier(identifier: str) -> str | None:
    value = identifier.strip()
    if not value:
        return None

    upper_value = value.upper()
    if upper_value in {"CRS84", "OGC:CRS84"} or upper_value.endswith(("/CRS84", ":CRS84")):
        return _GEOJSON_DEFAULT_CRS

    parts = [part for part in re.split(r"[:/]+", value) if part]
    for idx, part in enumerate(parts):
        if part.upper() == "EPSG":
            epsg_codes = [candidate for candidate in parts[idx + 1 :] if candidate.isdigit()]
            if epsg_codes:
                return f"EPSG:{epsg_codes[-1]}"

    return value


# ---------------------------------------------------------------------------
# Esri JSON geometry -> Shapely
# ---------------------------------------------------------------------------


def _coord_is_missing(value: Any) -> bool:
    """Whether an Esri point coordinate is absent/NaN and yields no geometry.

    Esri encodes "no geometry" points as ``None`` or ``NaN`` coordinates.
    Building ``Point(nan, nan)`` would produce an invalid geometry that leaks
    NaN coordinates downstream, so such coordinates are treated as missing.
    """
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    try:
        return bool(pd.isna(value))
    except (TypeError, ValueError):
        return False


def _esri_geometry_to_shapely(geom: dict[str, Any] | None) -> Any:  # noqa: PLR0911, PLR0912 -- geometry type dispatch
    """Convert a single Esri JSON geometry dict to a Shapely geometry.

    Returns ``None`` when *geom* is ``None`` or empty.
    """
    if geom is None:
        return None

    # --- Point ---
    if "x" in geom and "y" in geom:
        x = geom["x"]
        y = geom["y"]
        # Esri represents null-island-style "no geometry" as NaN coords.
        if _coord_is_missing(x) or _coord_is_missing(y):
            return None
        return Point(x, y)

    # --- Multipoint ---
    if "points" in geom:
        pts = geom["points"]
        if not pts:
            return None
        return MultiPoint([Point(*p) for p in pts])

    # --- Polyline ---
    if "paths" in geom:
        paths = geom["paths"]
        if not paths:
            return None
        lines = [list(map(tuple, path)) for path in paths]
        if len(lines) == 1:
            from shapely.geometry import LineString

            return LineString(lines[0])
        return MultiLineString(lines)

    # --- Polygon ---
    if "rings" in geom:
        rings = geom["rings"]
        if not rings:
            return None
        # Esri JSON encodes polygons as a flat list of rings.  By spec,
        # exterior rings are clockwise (not CCW) and holes are CCW, but
        # many real-world services emit rings with inconsistent winding.
        # We use a robust heuristic: a ring whose absolute area is large
        # is exterior; a ring that is CCW (opposite of Esri's exterior
        # convention) AND follows an exterior ring is a hole.  The first
        # ring is always treated as an exterior.
        exteriors: list[list[tuple[float, ...]]] = []
        holes_for: list[list[list[tuple[float, ...]]]] = []

        for idx, ring_coords in enumerate(rings):
            coords = [tuple(c) for c in ring_coords]
            lr = LinearRing(coords)
            # First ring is always exterior.  Subsequent rings:
            # if CCW it's a hole (Esri convention), otherwise exterior.
            if idx == 0 or not lr.is_ccw:
                exteriors.append(coords)
                holes_for.append([])
            # Hole - attach to most recent exterior
            elif holes_for:
                holes_for[-1].append(coords)

        if not exteriors:
            return None

        if len(exteriors) == 1:
            return Polygon(exteriors[0], holes_for[0])

        from shapely.geometry import MultiPolygon

        return MultiPolygon(
            [
                (ext, holes)
                for ext, holes in zip(exteriors, holes_for, strict=True)
            ]
        )

    return None


# ---------------------------------------------------------------------------
# Shapely -> Esri JSON geometry
# ---------------------------------------------------------------------------


def _shapely_to_esri_geometry(geom: Any) -> dict[str, Any] | None:  # noqa: PLR0911 -- geometry type dispatch
    """Convert a Shapely geometry to an Esri JSON geometry dict.

    Returns ``None`` when *geom* is ``None``.
    """
    if geom is None:
        return None

    from shapely.geometry import (
        LineString,
    )
    from shapely.geometry import (
        MultiLineString as _MLS,
    )
    from shapely.geometry import (
        MultiPoint as _MP,
    )
    from shapely.geometry import (
        MultiPolygon as _MPoly,
    )
    from shapely.geometry import (
        Point as _Pt,
    )
    from shapely.geometry import (
        Polygon as _Poly,
    )
    from shapely.geometry.polygon import orient as _orient

    if isinstance(geom, _Pt):
        return {"x": geom.x, "y": geom.y}

    if isinstance(geom, _MP):
        return {"points": [list(p.coords[0]) for p in geom.geoms]}

    if isinstance(geom, LineString):
        return {"paths": [[list(c) for c in geom.coords]]}

    if isinstance(geom, _MLS):
        return {"paths": [[list(c) for c in line.coords] for line in geom.geoms]}

    if isinstance(geom, _Poly):
        # Esri convention: exterior rings are clockwise, holes counter-clockwise.
        # ``orient(..., sign=-1.0)`` yields a CW exterior and CCW interiors.
        oriented = _orient(geom, sign=-1.0)
        rings: list[list[list[float]]] = []
        # Exterior ring
        rings.append([list(c) for c in oriented.exterior.coords])
        for interior in oriented.interiors:
            rings.append([list(c) for c in interior.coords])
        return {"rings": rings}

    if isinstance(geom, _MPoly):
        rings_all: list[list[list[float]]] = []
        for poly in geom.geoms:
            oriented = _orient(poly, sign=-1.0)
            rings_all.append([list(c) for c in oriented.exterior.coords])
            for interior in oriented.interiors:
                rings_all.append([list(c) for c in interior.coords])
        return {"rings": rings_all}

    raise TypeError(f"Unsupported geometry type: {type(geom).__name__}")


# ---------------------------------------------------------------------------
# Typed-model -> GeoDataFrame (the SEDF-equivalent first-class path)
# ---------------------------------------------------------------------------


def _crs_for_typed(crs_hint: Any, *, default_geojson: bool) -> str | None:
    """Resolve a CRS string from an explicit WKID/EPSG hint or GeoJSON default."""
    if crs_hint is not None:
        if isinstance(crs_hint, int):
            return _WKID_TO_EPSG.get(crs_hint, f"EPSG:{crs_hint}")
        if isinstance(crs_hint, str):
            text = crs_hint.strip()
            if text.isdigit():
                return _WKID_TO_EPSG.get(int(text), f"EPSG:{text}")
            return _normalize_geojson_crs_identifier(text)
    return _GEOJSON_DEFAULT_CRS if default_geojson else None


def typed_features_to_geodataframe(
    features: Any,
    *,
    crs: Any = None,
    default_geojson_crs: bool = True,
) -> gpd.GeoDataFrame:
    """Build a GeoDataFrame from typed ``Feature`` / ``QueryFeature`` objects.

    Each feature contributes its attribute mapping (``attributes`` for
    :class:`~honua_sdk.models.Feature`, ``properties`` for
    :class:`~honua_sdk.models.QueryFeature`) as a row and its geometry — via the
    feature's first-class ``__geo_interface__`` bridge — as the geometry column.
    This is the typed-model equivalent of the Esri Spatially-Enabled DataFrame:
    one call turns a query result into geopandas without round-tripping through
    ``result.raw``.

    Parameters
    ----------
    features:
        Iterable of :class:`Feature` / :class:`QueryFeature` instances.
    crs:
        Optional CRS hint (WKID int, EPSG string, or CRS identifier). When
        omitted, GeoJSON-shaped sources default to ``EPSG:4326`` unless
        *default_geojson_crs* is ``False``.
    """
    _ensure_deps()

    rows: list[dict[str, Any]] = []
    geometries: list[Any] = []
    for feature in features:
        attrs = getattr(feature, "attributes", None)
        if attrs is None:
            attrs = getattr(feature, "properties", {})
        row = dict(attrs)
        feature_id = getattr(feature, "id", None)
        if feature_id is not None and "id" not in row:
            row["id"] = feature_id
        rows.append(row)
        geo = feature.__geo_interface__
        geometries.append(_shape(geo) if geo else None)

    frame = pd.DataFrame(rows, dtype=object)
    gdf = gpd.GeoDataFrame(frame, geometry=geometries)
    resolved = _crs_for_typed(crs, default_geojson=default_geojson_crs)
    if resolved is not None:
        gdf = gdf.set_crs(resolved)
    return gdf


def result_to_geodataframe(result: Any) -> gpd.GeoDataFrame:
    """Convert a canonical :class:`~honua_sdk.models.Result` to a GeoDataFrame.

    Backs :meth:`honua_sdk.models.Result.to_geodataframe`. The CRS is taken from
    the result's ``query.out_sr`` when set, otherwise the result ``extent``'s
    spatial reference, otherwise the GeoJSON default ``EPSG:4326``.
    """
    crs_hint: Any = None
    query = getattr(result, "query", None)
    if query is not None and getattr(query, "out_sr", None) is not None:
        crs_hint = query.out_sr
    extent = getattr(result, "extent", None)
    if crs_hint is None and isinstance(extent, Mapping):
        spatial_reference = extent.get("spatialReference")
        if isinstance(spatial_reference, Mapping):
            for key in ("latestWkid", "wkid"):
                if spatial_reference.get(key) is not None:
                    crs_hint = spatial_reference[key]
                    break
    return typed_features_to_geodataframe(result.features, crs=crs_hint)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def features_to_geodataframe(
    response: dict[str, Any],
) -> gpd.GeoDataFrame:
    """Convert an Esri JSON feature-query response to a GeoDataFrame.

    Parameters
    ----------
    response:
        The raw dict returned by :pymeth:`HonuaClient.query_features`.
        Expected keys: ``features`` (list) and optionally
        ``spatialReference``.

    Returns
    -------
    geopandas.GeoDataFrame
        A GeoDataFrame with attributes as columns, a ``geometry`` column
        built from the Esri JSON geometries, and the CRS set when a
        spatial reference is present.
    """
    _ensure_deps()

    features = response.get("features", [])
    spatial_ref = response.get("spatialReference")
    crs = _crs_from_spatial_reference(spatial_ref)

    rows: list[dict[str, Any]] = []
    geometries: list[Any] = []

    for feat in features:
        attrs = dict(feat.get("attributes", {}))
        geom = _esri_geometry_to_shapely(feat.get("geometry"))
        rows.append(attrs)
        geometries.append(geom)

    gdf = gpd.GeoDataFrame(rows, geometry=geometries)

    if crs is not None:
        gdf = gdf.set_crs(crs)

    return gdf


def ogc_features_to_geodataframe(
    response: dict[str, Any],
) -> gpd.GeoDataFrame:
    """Convert an OGC API Features GeoJSON response to a GeoDataFrame.

    Parameters
    ----------
    response:
        A GeoJSON ``FeatureCollection`` dict, such as the response from
        ``HonuaOgcFeatureCollection.items``.

    Returns
    -------
    geopandas.GeoDataFrame
        A GeoDataFrame with feature ``properties`` as columns, a
        ``geometry`` column built from GeoJSON geometries, top-level
        feature ``id`` values preserved when they do not collide with
        property names, and CRS set from GeoJSON CRS metadata when
        present. GeoJSON responses without explicit CRS metadata default
        to ``EPSG:4326``.
    """
    return _geojson_feature_collection_to_geodataframe(
        response,
        feature_fields=("id",),
    )


def stac_items_to_geodataframe(
    response: dict[str, Any],
) -> gpd.GeoDataFrame:
    """Convert a STAC ItemCollection or search response to a GeoDataFrame.

    Parameters
    ----------
    response:
        A STAC ``ItemCollection`` or search result dict. STAC item
        collections and search results are GeoJSON ``FeatureCollection``
        objects whose features are STAC Items.

    Returns
    -------
    geopandas.GeoDataFrame
        A GeoDataFrame with item ``properties`` as columns, a
        ``geometry`` column built from item geometries, and common STAC
        item fields such as ``id``, ``collection``, ``bbox``, ``assets``,
        and item ``links`` preserved when they do not collide with
        property names. STAC geometries are treated as ``EPSG:4326`` when
        no explicit CRS metadata is present.
    """
    return _geojson_feature_collection_to_geodataframe(
        response,
        feature_fields=(
            "id",
            "collection",
            "bbox",
            "assets",
            "links",
            "stac_version",
            "stac_extensions",
        ),
    )


def _geojson_feature_collection_to_geodataframe(
    feature_collection: Mapping[str, Any],
    *,
    feature_fields: tuple[str, ...],
) -> gpd.GeoDataFrame:
    _ensure_deps()

    rows: list[dict[str, Any]] = []
    geometries: list[Any] = []

    for feature in feature_collection.get("features", []):
        properties = feature.get("properties")
        row = dict(properties) if isinstance(properties, Mapping) else {}

        for field in feature_fields:
            if field in feature and field not in row:
                row[field] = feature[field]

        geometry = feature.get("geometry")
        rows.append(row)
        geometries.append(_shape(geometry) if geometry else None)

    frame = pd.DataFrame(rows, dtype=object)
    gdf = gpd.GeoDataFrame(frame, geometry=geometries)
    crs = _crs_from_geojson(feature_collection)
    if crs is not None:
        gdf = gdf.set_crs(crs)

    return gdf


def _reproject_to_wgs84(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Reproject *gdf* to ``EPSG:4326`` for GeoJSON export.

    GeoJSON (RFC 7946) is defined in WGS84 longitude/latitude. A GeoDataFrame
    in a projected CRS would otherwise be serialized verbatim and silently
    mislabelled as ``EPSG:4326``, corrupting coordinates. When the frame
    already uses ``EPSG:4326`` (or carries no CRS, where reprojection is
    impossible) it is returned unchanged.
    """
    crs = gdf.crs
    if crs is None or crs.to_epsg() == _WGS84_EPSG:
        return gdf
    return gdf.to_crs(epsg=_WGS84_EPSG)


def _esri_spatial_reference_from_crs(crs: Any) -> dict[str, int] | None:
    """Build an Esri ``spatialReference`` dict from a GeoDataFrame CRS.

    Returns ``None`` when the CRS is absent or has no resolvable EPSG code, so
    callers omit the key rather than guessing. Web Mercator is emitted with the
    Esri ``wkid`` (``102100``) alongside ``latestWkid`` (``3857``) for maximum
    interoperability with Esri clients.
    """
    if crs is None:
        return None
    epsg = crs.to_epsg()
    if epsg is None:
        return None
    if epsg == _WEB_MERCATOR_EPSG:
        return {"wkid": _WEB_MERCATOR_ESRI_WKID, "latestWkid": _WEB_MERCATOR_EPSG}
    return {"wkid": epsg}


def geodataframe_to_features(
    gdf: gpd.GeoDataFrame,
) -> list[dict[str, Any]]:
    """Convert a GeoDataFrame to a list of Esri JSON feature dicts.

    This is useful for preparing data for
    :pymeth:`HonuaClient.apply_edits`.

    Parameters
    ----------
    gdf:
        A GeoDataFrame whose non-geometry columns become ``attributes``
        and whose geometry column becomes an Esri JSON ``geometry``.

    Returns
    -------
    list[dict]
        A list of ``{"attributes": {...}, "geometry": {...}}`` dicts
        ready for the ``adds`` or ``updates`` parameter of
        ``apply_edits``. The frame's CRS is preserved by stamping an explicit
        Esri ``spatialReference`` onto each emitted geometry, so a non-WGS84
        frame is no longer silently mislabelled as ``EPSG:4326``.
    """
    _ensure_deps()

    spatial_reference = _esri_spatial_reference_from_crs(gdf.crs)
    attr_columns = [col for col in gdf.columns if col != gdf.geometry.name]
    # Build attribute records columnar (one dict per row) instead of boxing a
    # pandas Series per row via ``.iloc`` — the per-row Series is a perf cliff
    # on bulk apply_edits. ``to_dict("records")`` on an empty column selection
    # returns ``[]``, so synthesize empty dicts for the geometry-only case.
    attr_records = (
        gdf[attr_columns].to_dict("records") if attr_columns else [{} for _ in range(len(gdf))]
    )
    geometries = gdf.geometry.to_numpy()

    features: list[dict[str, Any]] = []
    for raw_attrs, geom_obj in zip(attr_records, geometries, strict=True):
        attrs = {col: _json_safe_value(raw_attrs[col]) for col in attr_columns}
        esri_geom = _shapely_to_esri_geometry(geom_obj)
        feat: dict[str, Any] = {"attributes": attrs}
        if esri_geom is not None:
            if spatial_reference is not None:
                esri_geom["spatialReference"] = spatial_reference
            feat["geometry"] = esri_geom
        features.append(feat)

    return features


def geodataframe_to_geojson(
    gdf: gpd.GeoDataFrame,
) -> dict[str, Any]:
    """Convert a GeoDataFrame to a GeoJSON ``FeatureCollection`` dict.

    This is the inverse of :func:`ogc_features_to_geodataframe` and is used to
    feed a GeoDataFrame into an OGC API Processes execution as an inline
    ``FeatureCollection`` (see
    :pymeth:`honua_sdk.geoprocessing.HonuaGeoprocessing.execute_dataframe`).

    Parameters
    ----------
    gdf:
        A GeoDataFrame whose non-geometry columns become each feature's
        ``properties`` and whose geometry column becomes a GeoJSON
        ``geometry``.

    Returns
    -------
    dict
        A GeoJSON ``FeatureCollection`` mapping with a ``features`` list.
        Geometries are reprojected to ``EPSG:4326`` (the GeoJSON default CRS)
        when the frame carries a non-WGS84 CRS.
    """
    _ensure_deps()

    from shapely.geometry import mapping as _mapping

    gdf = _reproject_to_wgs84(gdf)
    attr_columns = [col for col in gdf.columns if col != gdf.geometry.name]
    # Columnar record extraction + a single geometry pass, avoiding a boxed
    # pandas Series per row (see ``geodataframe_to_features``).
    attr_records = (
        gdf[attr_columns].to_dict("records") if attr_columns else [{} for _ in range(len(gdf))]
    )
    geometries = gdf.geometry.to_numpy()

    features: list[dict[str, Any]] = []
    for raw_attrs, geom_obj in zip(attr_records, geometries, strict=True):
        properties = {col: _json_safe_value(raw_attrs[col]) for col in attr_columns}
        feature: dict[str, Any] = {
            "type": "Feature",
            "properties": properties,
            "geometry": None if geom_obj is None or geom_obj.is_empty else _mapping(geom_obj),
        }
        features.append(feature)

    return {"type": "FeatureCollection", "features": features}


def _json_safe_value(value: Any) -> Any:  # noqa: PLR0911 -- value type dispatch
    if value is None:
        return None
    if isinstance(value, dict):
        return {str(key): _json_safe_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe_value(item) for item in value]
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if hasattr(value, "item"):
        try:
            return value.item()
        except (TypeError, ValueError):
            pass
    return value
