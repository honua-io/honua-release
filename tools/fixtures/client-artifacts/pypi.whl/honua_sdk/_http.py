"""Shared HTTP utilities used by all Honua SDK client modules."""

from __future__ import annotations

import math
import uuid
import warnings
from collections.abc import Mapping
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime
from typing import Any
from urllib.parse import quote

import httpx
from anyio import to_thread

from .auth import SENSITIVE_AUTH_HEADER_NAMES, AuthProvider, normalize_auth_headers
from .errors import (
    HonuaAuthError,
    HonuaHttpError,
    HonuaRateLimitError,
    HonuaTimeoutError,
    HonuaTransportError,
    _http_failure_receipt,
)


def _normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/") + "/"


def _encode_path_segment(value: str) -> str:
    return quote(value, safe="")


def join_base_path(base_url: httpx.URL, path: str) -> str:
    """Join an endpoint *path* onto the base URL's existing path prefix.

    The core clients build each request URL by overriding the raw path on the
    base URL (via ``copy_with(raw_path=...)``) so httpx does not percent-decode
    already-encoded segments. That override would otherwise discard any path
    prefix on the configured base URL — so a deployment mounted behind a reverse
    proxy at a sub-path (e.g. ``https://host/honua/``) would have every call
    silently rewritten to ``/rest/services/...`` and hit the wrong endpoint.

    Prepend the base URL's path so sub-path hosting resolves correctly. A
    root base URL (path ``"/"`` or empty) leaves *path* unchanged.
    """
    prefix = base_url.path.rstrip("/")
    if not prefix:
        return path
    if not path.startswith("/"):
        path = "/" + path
    return prefix + path


def encode_request_path(raw_path: str) -> bytes:
    """Encode a joined request path to bytes for ``URL.copy_with(raw_path=…)``.

    The core clients override the raw path on the base URL so httpx does not
    percent-decode already-encoded segments — which requires an ASCII byte
    string. A server-controlled pagination ``next``-link path may however carry
    non-ASCII characters; ``str.encode("ascii")`` would raise an unwrapped
    :class:`UnicodeEncodeError` and crash the pagination walk.

    Encode the common all-ASCII case directly, and otherwise percent-encode
    **only** the non-ASCII characters (as UTF-8), leaving any existing
    percent-encoding (and reserved delimiters) untouched so already-encoded
    segments are not double-encoded.
    """
    try:
        return raw_path.encode("ascii")
    except UnicodeEncodeError:
        encoded = "".join(
            char if ord(char) < 128 else quote(char, safe="") for char in raw_path
        )
        return encoded.encode("ascii")


def build_idempotency_headers(
    idempotency_key: str | None,
    *,
    retry_methods: frozenset[str],
    extra: Mapping[str, str] | None = None,
) -> dict[str, str] | None:
    """Build an ``Idempotency-Key`` header dict, auto-generating when needed.

    ``extra`` is merged first, then an explicit ``idempotency_key`` wins. When
    no explicit key is supplied and ``POST`` has been opted into retryable
    methods, a fresh UUID hex key is generated so retried mutations can be
    de-duplicated server-side.
    """
    headers: dict[str, str] = {}
    if extra:
        headers.update(extra)
    if idempotency_key is not None:
        headers["Idempotency-Key"] = idempotency_key
    elif "POST" in retry_methods:
        headers["Idempotency-Key"] = uuid.uuid4().hex
    return headers or None


def merge_request_headers(
    headers: Mapping[str, str] | None,
    extra_headers: Mapping[str, str] | None,
    idempotency_key: str | None,
) -> dict[str, str] | None:
    """Merge per-request header overrides with stable precedence.

    Precedence from lowest to highest is ``extra_headers`` -> ``headers`` ->
    explicit ``idempotency_key``. Returns ``None`` when no headers are set so
    httpx's default header handling remains untouched.
    """
    if headers is None and extra_headers is None and idempotency_key is None:
        return None
    merged: dict[str, str] = {}
    if extra_headers:
        merged.update(extra_headers)
    if headers:
        merged.update(headers)
    if idempotency_key is not None:
        merged["Idempotency-Key"] = idempotency_key
    return merged


def _build_sensitive_auth_headers(
    *,
    api_key: str | None,
    bearer_token: str | None,
) -> dict[str, str]:
    headers: dict[str, str] = {}
    if api_key:
        headers["X-API-Key"] = api_key
    if bearer_token:
        headers["Authorization"] = f"Bearer {bearer_token}"
    return headers


def _validate_auth_configuration(
    *,
    bearer_token: str | None,
    auth_provider: AuthProvider | None,
) -> None:
    if bearer_token is not None and auth_provider is not None:
        raise ValueError("Provide either `bearer_token` or `auth_provider`, not both.")


def _warn_deprecated_bearer_token(
    bearer_token: str | None,
    *,
    stacklevel: int = 3,
) -> None:
    """Emit a :class:`DeprecationWarning` when ``bearer_token=`` is used.

    The ``bearer_token=`` constructor kwarg is deprecated in favor of the
    single ``auth_provider=`` parameter (mirroring the one-auth-parameter
    convention used by stripe-python / openai-python). Migrate callers to
    ``auth_provider=StaticAuthProvider({"Authorization": f"Bearer {token}"})``.
    Scheduled for removal in 0.2.x.

    ``stacklevel`` defaults to 3 so the warning points at the caller's
    constructor invocation (warn → ``_warn_deprecated_bearer_token`` →
    ``__init__`` → caller).
    """
    if bearer_token is None:
        return
    warnings.warn(
        "The `bearer_token=` constructor argument is deprecated and will be "
        "removed in 0.2.x. Pass authentication via `auth_provider=` instead, "
        'e.g. `auth_provider=StaticAuthProvider({"Authorization": f"Bearer '
        '{token}"})` (StaticAuthProvider is exported from honua_sdk.auth).',
        DeprecationWarning,
        stacklevel=stacklevel,
    )


def _validate_external_client_auth_configuration(
    *,
    client: object | None,
    api_key: str | None,
    bearer_token: str | None,
    auth_provider: AuthProvider | None,
) -> None:
    if client is None:
        return
    if api_key is None and bearer_token is None and auth_provider is None:
        return
    raise ValueError(
        "Configure authentication on the supplied `client`; "
        "`api_key`, `bearer_token`, and `auth_provider` are only applied "
        "when the SDK creates the HTTP client."
    )


def _extract_trusted_authority(url: httpx.URL) -> tuple[str, str, int | None]:
    """Return ``(scheme, host, port)`` from *url* for use as a trusted-origin key.

    Including the **scheme** alongside host and port prevents two distinct
    leaks on redirects: credentials configured for ``example.test:443`` are not
    sent to ``example.test:9999`` (different port), and — critically — they are
    not re-attached after an ``https`` → ``http`` downgrade. Without the scheme,
    ``https://api.example`` and ``http://api.example`` both normalize to host
    ``api.example`` / port ``None`` and would compare equal, leaking the
    ``Authorization`` / ``X-API-Key`` headers over plaintext.
    """
    return (url.scheme, url.host, url.port)


def _apply_sensitive_auth_headers(
    request: httpx.Request,
    *,
    trusted_authority: tuple[str, str, int | None] | None,
    auth_headers: Mapping[str, str],
    auth_provider: AuthProvider | None = None,
) -> None:
    """Attach or strip sensitive headers depending on the request target.

    Headers are only attached when the request's ``(scheme, host, port)``
    matches *trusted_authority* exactly; otherwise they are stripped to prevent
    credential leakage on redirects (including ``https`` → ``http`` downgrades).
    """
    if trusted_authority is None:
        return

    request_authority = (request.url.scheme, request.url.host, request.url.port)
    if request_authority == trusted_authority:
        dynamic_headers = _auth_provider_headers(auth_provider)
        for name, value in auth_headers.items():
            request.headers.setdefault(name, value)
        for name, value in dynamic_headers.items():
            request.headers.setdefault(name, value)
        return

    for name in SENSITIVE_AUTH_HEADER_NAMES:
        request.headers.pop(name, None)


def _auth_provider_headers(auth_provider: AuthProvider | None) -> dict[str, str]:
    if auth_provider is None:
        return {}
    return normalize_auth_headers(auth_provider.auth_headers())


async def _resolve_dynamic_auth_headers_async(
    auth_provider: AuthProvider | None,
) -> dict[str, str]:
    """Resolve dynamic provider headers without blocking the event loop.

    Prefers an awaitable ``auth_headers_async`` (see
    :class:`~honua_sdk.auth.AsyncAuthProvider`) so a network token refresh is
    awaited rather than run inline. A purely synchronous provider's
    ``auth_headers`` is executed in a worker thread so a blocking refresh does
    not stall the event loop.
    """
    if auth_provider is None:
        return {}
    async_getter = getattr(auth_provider, "auth_headers_async", None)
    if async_getter is not None:
        return normalize_auth_headers(await async_getter())
    headers = await to_thread.run_sync(auth_provider.auth_headers)
    return normalize_auth_headers(headers)


async def _apply_sensitive_auth_headers_async(
    request: httpx.Request,
    *,
    trusted_authority: tuple[str, str, int | None] | None,
    auth_headers: Mapping[str, str],
    auth_provider: AuthProvider | None = None,
) -> None:
    """Async variant of :func:`_apply_sensitive_auth_headers`.

    Resolves dynamic provider headers via
    :func:`_resolve_dynamic_auth_headers_async` so a refreshable bearer
    provider does not block the event loop, then applies the same
    trusted-origin gate (attach only on an exact ``(scheme, host, port)``
    match; strip the sensitive headers otherwise).
    """
    if trusted_authority is None:
        return

    request_authority = (request.url.scheme, request.url.host, request.url.port)
    if request_authority == trusted_authority:
        dynamic_headers = await _resolve_dynamic_auth_headers_async(auth_provider)
        for name, value in auth_headers.items():
            request.headers.setdefault(name, value)
        for name, value in dynamic_headers.items():
            request.headers.setdefault(name, value)
        return

    for name in SENSITIVE_AUTH_HEADER_NAMES:
        request.headers.pop(name, None)


def parse_retry_after(value: str | None) -> float | None:
    """Parse a ``Retry-After`` header value into seconds, if possible.

    Accepts either the delta-seconds form (``"120"``) or the RFC 7231
    HTTP-date form (``"Wed, 21 Oct 2026 07:28:00 GMT"``). For HTTP-date
    values the returned delay is ``max(0, target - now)`` so a date in
    the past becomes ``0.0``. Returns ``None`` for ``None`` input or any
    value that cannot be parsed as either form.

    Non-finite delta-seconds values (``"inf"``, ``"infinity"``, ``"nan"``,
    ``"1e400"``) are rejected as unparseable rather than producing an
    effectively infinite (or instant-retry) sleep. The caller is then free
    to fall back to bounded exponential backoff.
    """
    if value is None:
        return None
    text = value.strip()
    if not text:
        return None
    try:
        seconds = float(text)
    except (TypeError, ValueError):
        seconds = None
    # Reject inf/-inf/nan: a non-finite ``Retry-After`` would otherwise flow
    # un-capped into ``time.sleep`` and hang the client forever (or, for
    # ``nan``, silently coerce to retry-immediately). Treat it as "not a
    # delta-seconds value" so the HTTP-date branch (also a no-match here)
    # ultimately yields ``None``.
    if seconds is not None and not math.isfinite(seconds):
        seconds = None
    if seconds is not None:
        return max(0.0, seconds)
    try:
        target = parsedate_to_datetime(text)
    except (TypeError, ValueError):
        return None
    if target is None:
        return None
    if target.tzinfo is None:
        # RFC 7231 dates carry a zone; treat naive as UTC for safety.
        target = target.replace(tzinfo=UTC)
    return max(0.0, (target - datetime.now(UTC)).total_seconds())


# Back-compat alias for callers still pinned to the underscore spelling
# (re-exported from ``honua_sdk._shared`` and ``honua_sdk.http``).
_parse_retry_after = parse_retry_after


def _build_http_error(
    *,
    status_code: int,
    message: str,
    body: Any | None,
    response: httpx.Response,
) -> HonuaHttpError:
    """Construct the right :class:`HonuaHttpError` subtype for *status_code*."""
    request_id = (
        response.headers.get("x-request-id")
        or response.headers.get("honua-request-id")
        or response.headers.get("x-correlation-id")
    )
    headers = dict(response.headers)
    retry_after = _parse_retry_after(response.headers.get("retry-after"))
    receipt = _http_failure_receipt(
        transport_status=response.status_code,
        body=body,
        headers=headers,
        retry_after_seconds=retry_after,
    )
    if status_code in (401, 403):
        return HonuaAuthError(
            status_code,
            message,
            body=body,
            request_id=request_id,
            headers=headers,
            receipt=receipt,
        )
    if status_code == 429:
        return HonuaRateLimitError(
            status_code,
            message,
            body=body,
            retry_after=retry_after,
            request_id=request_id,
            headers=headers,
            receipt=receipt,
        )
    return HonuaHttpError(
        status_code,
        message,
        body=body,
        request_id=request_id,
        headers=headers,
        receipt=receipt,
    )


def _to_http_error(response: httpx.Response) -> HonuaHttpError:
    body: Any | None = None
    message = response.reason_phrase or "Request failed"

    if response.content:
        try:
            body = response.json()
        except ValueError:
            body = response.text
    if isinstance(body, Mapping):
        error = body.get("error")
        if isinstance(error, Mapping):
            candidate = error.get("message")
            if isinstance(candidate, str) and candidate:
                message = candidate
        else:
            candidate = body.get("detail") or body.get("message")
            if isinstance(candidate, str) and candidate:
                message = candidate

    return _build_http_error(
        status_code=response.status_code,
        message=message,
        body=body,
        response=response,
    )


def raise_for_geoservices_error(response: httpx.Response, payload: Mapping[str, Any]) -> None:
    """Raise if a successful (2xx) GeoServices JSON body carries an error envelope.

    The Esri GeoServices REST protocol (FeatureServer / MapServer / ImageServer
    / GeometryServer / GeocodeServer) reports failures as HTTP 200 with a body
    of the form ``{"error": {"code": <int>, "message": <str>, "details": [...]}}``
    rather than a non-success HTTP status. Without this check those errors flow
    back to callers as ordinary success dicts (e.g. an ``applyEdits`` that the
    server rejected would never raise). Detect that envelope and surface it
    through the same :class:`HonuaHttpError` hierarchy used for transport-level
    failures, carrying the server-reported error ``code``.

    The detection is deliberately narrow — it only fires when ``error`` is a
    mapping containing an integer ``code`` — so a legitimate payload that merely
    happens to include an ``"error"`` field is left untouched.
    """
    error = payload.get("error")
    if not isinstance(error, Mapping):
        return
    code = error.get("code")
    if not isinstance(code, int) or isinstance(code, bool):
        return

    message = response.reason_phrase or "GeoServices request failed"
    candidate = error.get("message")
    if isinstance(candidate, str) and candidate:
        message = candidate

    body: Any | None = payload
    if response.content:
        try:
            body = response.json()
        except ValueError:
            body = payload

    raise _build_geoservices_error(
        error_code=code,
        message=message,
        body=body,
        response=response,
    )


# Esri GeoServices auth/token error codes. These are an application code space,
# NOT HTTP statuses: 498 = Invalid Token, 499 = Token Required, 403 = permission
# denied. They must map to HonuaAuthError so ``except HonuaAuthError`` catches a
# token-required rejection (which previously surfaced as a generic HonuaHttpError).
_GEOSERVICES_AUTH_CODES = frozenset({401, 403, 498, 499})


def _normalize_geoservices_status(error_code: int) -> int:
    """Map a GeoServices envelope ``code`` onto a sane ``status_code`` surface.

    GeoServices codes are an application code space, so an arbitrary code (e.g. a
    large negative HRESULT-style value such as ``-2147217395``) must not be
    surfaced verbatim as an HTTP ``status_code``. Codes that already fall in the
    valid HTTP range are passed through; auth/token codes collapse to ``403``;
    everything else normalizes to ``500`` (server-side failure). The original
    code is always preserved on ``error_code``.
    """
    if error_code in _GEOSERVICES_AUTH_CODES:
        return error_code if error_code in (401, 403) else 403
    if 100 <= error_code <= 599:
        return error_code
    return 500


def _build_geoservices_error(
    *,
    error_code: int,
    message: str,
    body: Any | None,
    response: httpx.Response,
) -> HonuaHttpError:
    """Construct a Honua exception from an Esri GeoServices error envelope.

    Chooses the exception subtype from a GeoServices-aware mapping (auth/token
    codes -> :class:`HonuaAuthError`) rather than reinterpreting the envelope
    code as an HTTP status, and records the original Esri code on ``error_code``.
    """
    request_id = (
        response.headers.get("x-request-id")
        or response.headers.get("honua-request-id")
        or response.headers.get("x-correlation-id")
    )
    headers = dict(response.headers)
    status_code = _normalize_geoservices_status(error_code)
    retry_after = _parse_retry_after(response.headers.get("retry-after"))
    receipt = _http_failure_receipt(
        transport_status=getattr(response, "status_code", 200),
        body=body,
        headers=headers,
        protocol_code=error_code,
        retry_after_seconds=retry_after,
    )
    if error_code in _GEOSERVICES_AUTH_CODES:
        return HonuaAuthError(
            status_code,
            message,
            body=body,
            request_id=request_id,
            headers=headers,
            error_code=error_code,
            receipt=receipt,
        )
    if error_code == 429:
        return HonuaRateLimitError(
            status_code,
            message,
            body=body,
            retry_after=retry_after,
            request_id=request_id,
            headers=headers,
            error_code=error_code,
            receipt=receipt,
        )
    return HonuaHttpError(
        status_code,
        message,
        body=body,
        request_id=request_id,
        headers=headers,
        error_code=error_code,
        receipt=receipt,
    )


def _to_transport_error(error: httpx.HTTPError) -> HonuaTransportError:
    """Map an httpx transport-level error to the Honua exception hierarchy.

    ``httpx.TimeoutException`` becomes :class:`HonuaTimeoutError`; every
    other transport-level :class:`httpx.RequestError` (and any other
    :class:`httpx.HTTPError` arriving without a response) becomes
    :class:`HonuaTransportError`.
    """
    message = str(error) or error.__class__.__name__
    request = getattr(error, "request", None)
    url = str(request.url) if request is not None else None
    detail = f"Transport error: {message}"

    if isinstance(error, httpx.TimeoutException):
        exc: HonuaTransportError = HonuaTimeoutError(detail)
    else:
        exc = HonuaTransportError(detail)

    exc.cause_type = error.__class__.__name__  # type: ignore[attr-defined]
    exc.url = url  # type: ignore[attr-defined]
    return exc
